import React from "react";
import "./Navbar.css"; // Import navbar styles

const Navbar = () => {
    return (
        <nav className="navbar">
            <h2>NexTech</h2>
            <ul>
      
            </ul>
        </nav>
    );
};

export default Navbar;
